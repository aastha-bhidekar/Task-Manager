// AddTask.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AddTask = ({ addTask }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assignee, setAssignee] = useState('');
  const [priority, setPriority] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validate inputs
    if (!title || !assignee || !priority || !status) {
      alert('Please fill in all required fields.');
      return;
    }
    // Set start date to current date
    const startDate = new Date().toLocaleDateString();
    // Call addTask function from parent component
    addTask({ title, description, assignee, priority, status, startDate });
    // Reset form fields
    setTitle('');
    setDescription('');
    setAssignee('');
    setPriority('');
    setStatus('');
    // Navigate back to Task Tracker page
    navigate('/');
  };

  return (
    <div>
      <h2>Add Task</h2>
      <form onSubmit={handleSubmit}>
        <label>Title:</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
        
        <label>Description:</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)}></textarea>
        
        <label>Assignee:</label>
        <input type="text" value={assignee} onChange={(e) => setAssignee(e.target.value)} required />
        
        <label>Priority:</label>
        <select value={priority} onChange={(e) => setPriority(e.target.value)} required>
          <option value="">Select Priority</option>
          <option value="P0">P0</option>
          <option value="P1">P1</option>
          <option value="P2">P2</option>
        </select>

        <label>Status:</label>
        <select value={status} onChange={(e) => setStatus(e.target.value)} required>
          <option value="">Select Status</option>
          <option value="Pending">Pending</option>
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
          <option value="Deployed">Deployed</option>
          <option value="Deferred">Deferred</option>
        </select>
        
        <button type="submit">Add Task</button>
      </form>
    </div>
  );
};

export default AddTask;
