// Task.js

import React from 'react';

function Task({ task }) {
  const { title, description, assignee, priority, status } = task;

  return (
    <div className="task">
      <div className="task-header">
        <h3>{title}</h3>
        <div className="priority-box">{priority}</div>
      </div>
      <hr />
      <p>{description}</p>
      <p>Assignee: {assignee}</p>
      <p className="status-box">{status}</p>
    </div>
  );
}

export default Task;
